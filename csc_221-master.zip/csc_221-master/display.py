# CSC221
# M3L1_CanjuraHylton
# Goal: [Gold]

"""
holds output for program
"""

def welcomeMessage():
    
    welcome = "Welcome to RedFox Video Rental Store.<br>"
    
    return welcome

def movieName():
    
    movieName = "Enter the title of the movie youd like to rent: "
    
    return movieName   

def movieFormat():
    
    movieFormat = "Select the movie format: "
    
    return movieFormat
    
def loginMenu():
    loginMenu = '''
    To continue please select an option below:
    <br><a href="login">1.Login</a>
    <br><button>2.Create Account</button>
    '''
    return loginMenu
    
def invalidInput():
    
    invalidInput = "Invalid input. <br>Try again."
    
    return invalidInput

def rentReturnMenu():
    rentMenu = "<button>1. Rent</button><br>"\
                "<button>2. Return</button><br>"\
                "<button>3. Exit</button><br>"
    return rentMenu

def searchMovies():
    
    search = "Select an option to view movies: <br>1.New Releases<br>2.Regular<br>3.Childrens<br>4.All Movies<br>5.Search Movie by Name<br>"
    
    return search
            
