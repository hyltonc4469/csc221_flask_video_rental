

import display
import login as l
import validateInput as v
import rentReturn 
from checkout import checkOut
import listBuilder as listB
from flask import Flask, request,render_template, url_for, redirect
app=Flask(__name__)

cart = []
outCart = []
totAddCost = 0
maxOption = 2
returned = []

@app.route('/welcome')
def welcome():
    
 #   decision = v.menu(display.loginMenu(),maxOption)     
    # uses user input to login or create account    
 #   customer = l.loginDecision(decision)

    return('''<body style=""><h1 style="color:red;">'''+display.welcomeMessage()+'''</h1></body>'''+
           '''<h2>'''+display.loginMenu()+'''</h2>''')

@app.route('/login', methods=['GET','POST'])
def login():
    error=None
    if request.method=='POST':
        username=request.form['username']
        password=request.form['password']
    return( '''<form method="POST">
                Username:<input type="text" name="username"><br>
            Password:<input type="password" name="password"><br>
            <input type="submit" value="Submit"><br></form>''')

@app.route('/dashboard')
def rentReturnMenu():
    return display.rentReturnMenu()



    
if __name__=='__main__':
    app.run(debug=True, port=5000)
